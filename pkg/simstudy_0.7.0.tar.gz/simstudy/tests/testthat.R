library(testthat)
library(hedgehog)
library(simstudy)


test_check("simstudy")
