rm(list = setdiff(names(.GlobalEnv), freeze), pos = .GlobalEnv)
